# YONOD 严谨模型比较报告

生成时间：`2026-11-13 12:58:57`  
run_id：`reactions-2be664e4d329`

> 本报告只读取 `docs/manifests/`、`docs/predictions/`、`docs/folds/` 和 `docs/metrics/`，不重新训练模型。

## 实验可追溯性

| run_id | config_hash | dataset_sha256 | code_git_commit | dataset_path | grouping | cv | derived_from |
|---|---|---|---|---|---|---|---|
| reactions-2be664e4d329 | 2be664e4d3299cf2d297a05787937af7faabe9e4d158f0cc6fc7c05a2c7bbe94 | f67415bd6ba2496bc7b890f8241169febbd8a54bde8341b23b046d099ab65ff8 | 6976cce36fa92fc33f3fd0f5be8155ae0fb871af | /home/wangzh685/桌面/ord-data/YONOD/example/fixed_split/dataset/reactions.csv | {"group_column": "fixed_block", "strategy": "precomputed_column"} | {"n_repeats": 1, "n_splits": 2, "seed": 42} | docs/manifests/, docs/predictions/, docs/folds/, docs/metrics/ |

## 论文协议对齐状态

此处记录特征、切分与随机种子的运行证据；流程对齐不等同于论文数值复现，仍需核对数据和软件版本。

| protocol | status |
|---|---|
| 未声明论文协议 | 通用 benchmark；不可据此宣称论文流程对齐 |

## 切分审计

| split_id | repeat | fold | n_train | n_valid | n_train_groups | n_valid_groups | max_group_size | group_leakage |
|---|---|---|---|---|---|---|---|---|
| teaching-fixed-two-fold-v1 | 1 | 1 | 6 | 6 | 1 | 1 | 6 | False |
| teaching-fixed-two-fold-v1 | 1 | 2 | 6 | 6 | 1 | 1 | 6 | False |

## 描述符预计算状态

建模任务只读取 `descriptors/*.npz`；失败描述符的模型任务被隔离跳过。

| descriptor | status | stage | artifact_path | n_total | n_valid | feature_dim | skipped_model_count | reason |
|---|---|---|---|---|---|---|---|---|
| morgan | computed | precompute | /home/wangzh685/桌面/ord-data/YONOD/example/fixed_split/result/example_fixed_split_20261113/feature/morgan.npz | 12 | 12 | 2048 | 0 | 首次生成描述符文件 |

## 模型协议与严格排名守卫

strict benchmark 的比较/排名只纳入 `evaluation_protocol=manifest_outer_cv` 且 expected/valid fold 完整的组合；旧 `autogluon_internal_holdout` 只展示并明确排除。

| split_id | descriptor | model | evaluation_protocol | expected_folds | valid_metric_folds | is_complete | strict_rank_eligible | strict_rank_exclusion_reason | autogluon_time_limit | autogluon_presets | autogluon_num_cpus | autogluon_seed_policy | autogluon_version | model_artifact_cleanup |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| teaching-fixed-two-fold-v1 | morgan | rf | manifest_outer_cv | 2 | 2 | True | True | 可进入 strict benchmark 比较/排名 | — | — | — | — | — | — |

## 性能矩阵与完成度

| split_id | evaluation_protocol | descriptor | model | r2 | r2_std | rmse | rmse_std | mae | mae_std | complete | expected_folds | valid_metric_folds |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| teaching-fixed-two-fold-v1 | manifest_outer_cv | morgan | rf | -12.7646 | 0.1920 | 0.3802 | 0.0027 | 0.3460 | 0.0040 | True | 2 | 2 |

| run_id | config_hash | split_id | evaluation_protocol | descriptor | model | expected_folds | available_folds | valid_metric_folds | is_complete | missing_or_excluded_reason |
|---|---|---|---|---|---|---|---|---|---|---|
| reactions-2be664e4d329 | 2be664e4d3299cf2d297a05787937af7faabe9e4d158f0cc6fc7c05a2c7bbe94 | teaching-fixed-two-fold-v1 | manifest_outer_cv | morgan | rf | 2 | 2 | 2 | True |  |


## 训练与外层评估诊断

训练分数是已见样本上的拟合诊断；基线为每折 outer-train 标签均值。R² 差距为训练减外层，RMSE/MAE 差距为外层减训练。缺失状态不参与外层排名。

| feature | model | repeat | fold | status | reason | worst_sample_id | worst_residual_y_true_minus_pred | heldout_target_min | heldout_target_max | worst_group_id | worst_source_row_index |
|---|---|---|---|---|---|---|---|---|---|---|---|
| morgan | rf | 1 | 1 | disabled | disabled | fixed-01 | -0.6120 | 0.1000 | 0.4000 | precomputed:block_A | 0 |
| morgan | rf | 1 | 2 | disabled | disabled | fixed-12 | 0.5460 | 0.4600 | 0.7600 | precomputed:block_B | 11 |

### 按 repeat 折间汇总

标准差使用 ddof=0，各指标分别披露有效折数。

| feature | model | repeat | expected_folds | complete_folds | missing_or_failed_folds | std_ddof | train_r2_n | train_r2_mean | train_r2_std | train_rmse_n | train_rmse_mean | train_rmse_std | train_mae_n | train_mae_mean | train_mae_std | heldout_r2_n | heldout_r2_mean | heldout_r2_std | heldout_rmse_n | heldout_rmse_mean | heldout_rmse_std | heldout_mae_n | heldout_mae_mean | heldout_mae_std | baseline_r2_n | baseline_r2_mean | baseline_r2_std | baseline_rmse_n | baseline_rmse_mean | baseline_rmse_std | baseline_mae_n | baseline_mae_mean | baseline_mae_std | gap_r2_n | gap_r2_mean | gap_r2_std | gap_rmse_n | gap_rmse_mean | gap_rmse_std | gap_mae_n | gap_mae_mean | gap_mae_std |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| morgan | rf | 1 | 2 | 0 | 2 | 0 | 0 | None | None | 0 | None | None | 0 | None | None | 0 | None | None | 0 | None | None | 0 | None | None | 0 | None | None | 0 | None | None | 0 | None | None | 0 | None | None | 0 | None | None | 0 | None | None |

### 全量外层留出样本与组追溯

逐样本残差为 y_true − y_pred；组表保留全部组与折。少于 2 个留出样本的组不宜解释为稳定规律；opaque 组键不能推断反应类型。完整数据：[逐样本 CSV](diagnostic_sample_trace.csv)、[逐组 CSV](diagnostic_group_trace.csv)。

| feature | model | repeat | fold | group_id | group_kind | n_train | n_heldout | target_min | target_max | mean_absolute_error | max_absolute_error | worst_sample_id | small_group | status | reason |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| morgan | rf | 1 | 1 | precomputed:block_A | opaque | 0 | 6 | 0.1000 | 0.4000 | 0.3420 | 0.6120 | fixed-01 | False | complete |  |
| morgan | rf | 1 | 2 | precomputed:block_B | opaque | 0 | 6 | 0.4600 | 0.7600 | 0.3500 | 0.5460 | fixed-12 | False | complete |  |

| feature | model | repeat | fold | sample_id | y_true | y_pred | residual_y_true_minus_pred | absolute_error | group_id | source_row_index | trace_status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| morgan | rf | 1 | 1 | fixed-01 | 0.1000 | 0.7120 | -0.6120 | 0.6120 | precomputed:block_A | 0 | complete |
| morgan | rf | 1 | 1 | fixed-02 | 0.1600 | 0.6880 | -0.5280 | 0.5280 | precomputed:block_A | 1 | complete |
| morgan | rf | 1 | 1 | fixed-03 | 0.2200 | 0.5380 | -0.3180 | 0.3180 | precomputed:block_A | 2 | complete |
| morgan | rf | 1 | 1 | fixed-04 | 0.2800 | 0.5380 | -0.2580 | 0.2580 | precomputed:block_A | 3 | complete |
| morgan | rf | 1 | 1 | fixed-05 | 0.3400 | 0.5380 | -0.1980 | 0.1980 | precomputed:block_A | 4 | complete |
| morgan | rf | 1 | 1 | fixed-06 | 0.4000 | 0.5380 | -0.1380 | 0.1380 | precomputed:block_A | 5 | complete |
| morgan | rf | 1 | 2 | fixed-07 | 0.4600 | 0.3100 | 0.1500 | 0.1500 | precomputed:block_B | 6 | complete |
| morgan | rf | 1 | 2 | fixed-08 | 0.5200 | 0.2860 | 0.2340 | 0.2340 | precomputed:block_B | 7 | complete |
| morgan | rf | 1 | 2 | fixed-09 | 0.5800 | 0.3100 | 0.2700 | 0.2700 | precomputed:block_B | 8 | complete |
| morgan | rf | 1 | 2 | fixed-10 | 0.6400 | 0.2200 | 0.4200 | 0.4200 | precomputed:block_B | 9 | complete |
| morgan | rf | 1 | 2 | fixed-11 | 0.7000 | 0.2200 | 0.4800 | 0.4800 | precomputed:block_B | 10 | complete |
| morgan | rf | 1 | 2 | fixed-12 | 0.7600 | 0.2140 | 0.5460 | 0.5460 | precomputed:block_B | 11 | complete |


## 建模耗时与成本对比

时间口径：`total_model_time_s = total_train_time_s + total_predict_time_s`，均为该组合全部有效外部 CV fold 的累计值。描述符特征化与 CLI 端到端墙钟时间不计入柱状图；不完整、缺失或非法时间的组合保留状态，但不进入耗时排序。描述符和建模方法图是组合成本的两种汇总视图，不应与组合图相加，也不把共享特征化时间重复归因给模型。

### 描述符 × 建模方法组合

| run_id | config_hash | split_id | evaluation_protocol | descriptor | model | expected_folds | completed_folds | is_complete | time_status | time_status_detail | is_time_comparable | total_train_time_s | mean_train_time_s | median_train_time_s | max_train_time_s | total_predict_time_s | total_model_time_s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| reactions-2be664e4d329 | 2be664e4d3299cf2d297a05787937af7faabe9e4d158f0cc6fc7c05a2c7bbe94 | teaching-fixed-two-fold-v1 | manifest_outer_cv | morgan | rf | 2 | 2 | True | complete_and_comparable |  | True | 0.0278 | 0.0139 | 0.0139 | 0.0148 | 0.0231 | 0.0509 |

![组合级建模耗时柱状图](../pictures/combination_modeling_time.png)

### 按描述符汇总

每根柱为该描述符下所有完整且时间可比较模型组合的累计时间。

| run_id | config_hash | split_id | evaluation_protocol | aggregation_dimension | item | expected_combinations | comparable_combinations | noncomparable_combinations | is_time_comparable | time_status | time_status_detail | total_train_time_s | total_predict_time_s | total_model_time_s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| reactions-2be664e4d329 | 2be664e4d3299cf2d297a05787937af7faabe9e4d158f0cc6fc7c05a2c7bbe94 | teaching-fixed-two-fold-v1 | manifest_outer_cv | descriptor | morgan | 1 | 1 | 0 | True | complete_and_comparable |  | 0.0278 | 0.0231 | 0.0509 |

![描述符累计建模耗时柱状图](../pictures/descriptor_modeling_time.png)

### 按建模方法汇总

每根柱为该建模方法在所有描述符下完整且时间可比较组合的累计时间。

| run_id | config_hash | split_id | evaluation_protocol | aggregation_dimension | item | expected_combinations | comparable_combinations | noncomparable_combinations | is_time_comparable | time_status | time_status_detail | total_train_time_s | total_predict_time_s | total_model_time_s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| reactions-2be664e4d329 | 2be664e4d3299cf2d297a05787937af7faabe9e4d158f0cc6fc7c05a2c7bbe94 | teaching-fixed-two-fold-v1 | manifest_outer_cv | model | rf | 1 | 1 | 0 | True | complete_and_comparable |  | 0.0278 | 0.0231 | 0.0509 |

![建模方法累计建模耗时柱状图](../pictures/model_modeling_time.png)

## 预测与稳定性

![fold_metric_stability.png](../pictures/fold_metric_stability.png)
![prediction_residuals.png](../pictures/prediction_residuals.png)

## 双维统计比较

### 模型维度统计比较（固定描述符）

- 没有可比较的完整组合；这不是性能排名结论。

无可展示记录；请查看相应排除/完整性表。

## 描述符维度统计比较（固定模型）

- 没有可比较的完整组合；这不是性能排名结论。

无可展示记录；请查看相应排除/完整性表。

## Tukey HSD 多重比较

### 模型维度

无可展示记录；请查看相应排除/完整性表。

### 描述符维度

无可展示记录；请查看相应排除/完整性表。

## 成本、任务状态与失败

| run_dir | disk_bytes | all_valid_fold_cumulative_train_time_s | all_valid_fold_cumulative_predict_time_s | all_valid_fold_cumulative_model_time_s | time_comparable_combinations | time_noncomparable_combinations | metric_exclusions | comparison_exclusions |
|---|---|---|---|---|---|---|---|---|
| /home/wangzh685/桌面/ord-data/YONOD/example/fixed_split/result/example_fixed_split_20261113 | 421298 | 0.0278 | 0.0231 | 0.0509 | 1 | 0 | 0 | 0 |

| state_store | count |
|---|---|
| succeeded | 2 |

无可展示记录；请查看相应排除/完整性表。

## 统计限制

比较单位是 CV fold。折之间并非完全独立，p 值不是唯一证据；必须结合差值、bootstrap CI、稳定性图和缺失任务解读。`no_significant_difference` 不代表性能完全相同。Tukey HSD 与配对检验并列呈现，不可任选有利结果。
