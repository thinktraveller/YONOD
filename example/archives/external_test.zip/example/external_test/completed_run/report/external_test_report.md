# Frozen development → external test report

## Protocol boundary

This report contains one fit on the declared development population and one prediction on the declared external population. It is **not CV**, has no folds, and is ineligible for strict-CV ranking.

- evaluation protocol: `frozen_train_external_test`
- run ID: `frozen-external-e3feb5e08afe`
- train rows: 12
- external rows: 6
- external bootstrap groups retained in prediction artifact: 3
- train/external sample-ID intersection: 0 (validated before descriptors or fit)
- external labels were loaded only after each prediction was generated in memory.

## Single external-test metrics

| run_id | config_hash | evaluation_protocol | descriptor | model | n_external | mae | rmse | r2 | kendall_tau | train_time_s | predict_time_s | cv_folds | strict_rank_eligible |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| frozen-external-e3feb5e08afe | e3feb5e08afe0bdf0cd09b8574db855c6785ec99c2fdc30dd72bce79903c9e52 | frozen_train_external_test | morgan | rf | 6 | 0.176667 | 0.196554 | -0.490835 | 0.733333 | 0.005145 | 0.000232 | 0 | False |

No confidence interval, hypothesis test, or equivalence conclusion is produced here. Those require the pre-specified grouped analysis over the saved external prediction records.

## Audit fingerprints

- external standardized data SHA-256: `1801f2879cc2486983cfc5c33ab0c5b7fe26f18bbe1f91766e52d9f1dc06e44f`
- audit manifest SHA-256: `e4145e45f41d95003509380960496a1b43b0ef86290f9ed0d72fcf5066b1be77`
- train sample-ID SHA-256: `34b70f498141f2ebad7e45c91cd064805fca6544c7342b7e1c0bce2608df7e6e`
- external sample-ID SHA-256: `452c063bd280c376b868936e83d5ffa807ee6fa9bbb6b13466dd88731feb48fc`
